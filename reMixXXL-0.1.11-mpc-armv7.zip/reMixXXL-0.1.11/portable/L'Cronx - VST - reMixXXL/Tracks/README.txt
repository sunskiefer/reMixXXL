Put WAV, FLAC or MP3 files here (the Tracks folder of the plugin), or pick any folder on the BROWSE page.
